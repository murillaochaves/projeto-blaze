export type SeedingEvent = (...args: any[]) => Promise<any>;

// export async function SeedingEvent(ttl: number = 6) {

// }
