export type ProofOfExistence = (...args: any[]) => Promise<any>;
