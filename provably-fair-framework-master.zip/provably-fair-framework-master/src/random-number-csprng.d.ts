declare module 'random-number-csprng';
