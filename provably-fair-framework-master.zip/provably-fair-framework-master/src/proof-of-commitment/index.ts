export type ProofOfCommitment = (...args: any[]) => Promise<any>;
